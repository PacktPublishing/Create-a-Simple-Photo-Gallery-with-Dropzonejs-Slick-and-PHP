<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Multi File Upload</title>
    <link href="style/dropzone.css" type="text/css" rel="stylesheet" />
    <script src="scripts/dropzone.js"></script>
    <script src="scripts/validate.js"></script>
</head>

<body>
<form action="parser.php" id="uploads" class="dropzone"></form>

<p><a href="index.php">View Upload</a> </p>

<div id="msg"></div>
</body>
</html>