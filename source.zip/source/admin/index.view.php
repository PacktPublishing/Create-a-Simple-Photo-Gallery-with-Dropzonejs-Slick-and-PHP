<!DOCTYPE html>
<html lang="en">
<head>
    <title>Manage Gallery</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
</head>
<body>

<div class="container">
    <div class="row mt-4">
        <?php if($statement->rowCount() > 0): ?>
            <div class="col-12 col-md-8 col-lg-7 mx-auto">
                <h2>Manage Photo Gallery</h2>
                
                <?php if(isset($message)): ?>
                    <div class="alert alert-<?= $alert_class_name ?> alert-dismissible fade show" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        <?= $message ?>
                    </div>
                <?php endif; ?>
                
                <table class="table table-bordered table-hover table-sm">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Image</th>
                        <th>Showing</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php while ($image = $statement->fetch(PDO::FETCH_OBJ)): ?>
                        <tr>
                            <th scope="row" width="20"><?= $image->id ?></th>
                            <td width="40">
                                <img src="../<?= $image->path ?>" width="40" height="40">
                            </td>
                            <td>
                                <form class="form-inline" method="post">
                                    <div class="form-group">
                                        <select style="width: 250px;" name="showing" class="form-control">
                                            <option value="<?= $image->showing ?>">
                                                <?= $image->showing ? 'Showing' : 'Hidden' ?>
                                            </option>
                                            <option value="0">Hide</option>
                                            <option value="1">Show</option>
                                        </select>
                                        <input type="hidden" name="id" value="<?= $image->id ?>">
                                    </div>
                                    <button type="submit" class="btn btn-outline-success">
                                        Change Status
                                    </button>
                                </form>
                            </td>
                            <td width="70">
                                <a onclick="return confirm('Do you really want to delete this image');"
                                   class="btn btn-outline-danger" href="index.php?delete=<?= $image->id ?>">
                                    Delete
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <h2>You have not uploaded any file</h2>
        <?php endif; ?>
    </div>
    <p><a href="../index.php">View Gallery</a> </p>
</div>


<script src="https://code.jquery.com/jquery-3.1.1.min.js"
        integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js" integrity="sha384-alpBpkh1PFOepccYVYDB4do5UnbKysX5WZXm3XxPqe5iKTfUKjNkCk9SaVuEZflJ" crossorigin="anonymous"></script>
</body>
</html>
