<?php
define('DSN', "mysql:host=localhost;dbname=dropzone");
define('USERNAME', 'root');
define('PASSWORD', '');

try{
    $conn = new PDO(DSN, USERNAME, PASSWORD);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
  /*  echo "Connected successfully";
    var_dump($conn->query("DESC images")->fetch(PDO::FETCH_OBJ));
    exit;*/
    
}catch (PDOException $ex){
    echo "Database connectivity Issue " . $ex->getMessage();
    exit;
}
